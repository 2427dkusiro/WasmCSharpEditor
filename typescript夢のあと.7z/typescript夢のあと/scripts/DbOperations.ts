﻿import * as Dexie from "dexie";

interface DBData {
    key: string,
    type: string,
    data: Uint8Array
}

class MyDataBase extends Dexie.Dexie {
    table1: Dexie.Dexie.Table<DBData, string>;

    constructor() {
        super("shared");
        this.version(1).stores({
            table1: "key"
        });
    }

    Add(_key: string, _type: string, _data: Uint8Array): void {
        this.table1.add({ key: _key, type: _type, data: _data });
    }

    GetData(_key: string): Promise<Uint8Array> {
        return this.table1.get(_key).then(result => result.data);
    }
}

const myDataBase = new MyDataBase();

export function Add(key: string, type: string, data: Uint8Array): void {
    myDataBase.Add(key, type, data);
}