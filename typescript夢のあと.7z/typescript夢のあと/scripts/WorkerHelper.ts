﻿function test() {
    console.info("スクリプトはワーカーから正常に実行されました。");
}