"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddString = void 0;
function AddString(guid, data) {
    console.info(guid + data);
}
exports.AddString = AddString;
//# sourceMappingURL=DbOperations.js.map