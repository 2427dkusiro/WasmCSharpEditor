"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InitializeCodeEditor = exports.EnableEventRaising = exports.Save = void 0;
var editer;
var textAreaId;
var eventGuid;
var CodeMirror = require("codemirror");
function Save() {
    editer.save();
    return document.getElementById(textAreaId).value;
}
exports.Save = Save;
function EnableEventRaising(guid) {
    eventGuid = guid;
}
exports.EnableEventRaising = EnableEventRaising;
function InitializeCodeEditor(id) {
    editer = CodeMirror.fromTextArea(document.getElementById(id), {
        mode: "text/x-csharp",
        lineNumbers: true,
    });
    editer.on("change", OnChange);
    textAreaId = id;
}
exports.InitializeCodeEditor = InitializeCodeEditor;
function OnChange() {
    if (eventGuid == null) {
        return;
    }
    DotNet.invokeMethodAsync("WasmCsTest", "RaiseOnChangeEventFromJs", eventGuid);
}
//# sourceMappingURL=CodeEditorHandler.js.map