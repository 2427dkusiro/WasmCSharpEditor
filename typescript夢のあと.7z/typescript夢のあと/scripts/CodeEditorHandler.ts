﻿let editer : CodeMirror.EditorFromTextArea;
let textAreaId : string;
let eventGuid: string;
import * as CodeMirror from "codemirror"

export function Save() : string {
    editer.save();
    return (document.getElementById(textAreaId) as HTMLFormElement).value;
}

export function EnableEventRaising(guid: string) : void {
    eventGuid = guid;
}

export function InitializeCodeEditor(id : string) : void {
    editer = CodeMirror.fromTextArea(document.getElementById(id) as HTMLTextAreaElement, {
        mode: "text/x-csharp",
        lineNumbers: true,
    });
    editer.on("change", OnChange)
    textAreaId = id;
}

function OnChange() : void {
    if (eventGuid == null) {
        return;
    }
    DotNet.invokeMethodAsync("WasmCsTest", "RaiseOnChangeEventFromJs", eventGuid);
}